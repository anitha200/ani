import datetime

class Patient:
    def __init__(self, name, age, patient_id):
        self.name = name
        self.age = age
        self.patient_id = patient_id
        self.reports = []
    
    def add_report(self, diagnosis, doctor_name):
        report = {
            "date": datetime.date.today(),
            "diagnosis": diagnosis,
            "doctor_name": doctor_name
        }
        self.reports.append(report)
        print(f"\nReport added for {self.name} on {report['date']}.")

    def view_reports(self):
        if not self.reports:
            print(f"\nNo reports available for {self.name}.")
        else:
            print(f"\nReports for {self.name}:")
            for report in self.reports:
                print(f"Date: {report['date']}, Diagnosis: {report['diagnosis']}, Doctor: {report['doctor_name']}")
    
    def get_latest_report(self):
        if not self.reports:
            print(f"\nNo reports available for {self.name}.")
        else:
            latest_report = self.reports[-1]
            print(f"\nLatest report for {self.name}:")
            print(f"Date: {latest_report['date']}, Diagnosis: {latest_report['diagnosis']}, Doctor: {latest_report['doctor_name']}")

class HealthMonitoringSystem:
    def __init__(self):
        self.patients = {}

    def register_patient(self, name, age):
        patient_id = len(self.patients) + 1
        patient = Patient(name, age, patient_id)
        self.patients[patient_id] = patient
        print(f"\nPatient {name} registered with ID {patient_id}.")

    def find_patient(self, patient_id):
        return self.patients.get(patient_id, None)

    def add_diagnosis(self, patient_id, diagnosis, doctor_name):
        patient = self.find_patient(patient_id)
        if patient:
            patient.add_report(diagnosis, doctor_name)
        else:
            print("\nPatient not found.")

    def view_patient_reports(self, patient_id):
        patient = self.find_patient(patient_id)
        if patient:
            patient.view_reports()
        else:
            print("\nPatient not found.")
    
    def view_latest_report(self, patient_id):
        patient = self.find_patient(patient_id)
        if patient:
            patient.get_latest_report()
        else:
            print("\nPatient not found.")

    def run(self):
        while True:
            print("\nAutomatic Health Monitoring System")
            print("1. Register Patient")
            print("2. Add Diagnosis Report")
            print("3. View All Reports")
            print("4. View Latest Report")
            print("5. Exit")
            
            choice = input("Enter your choice: ")
            if choice == '1':
                name = input("Enter patient's name: ")
                age = int(input("Enter patient's age: "))
                self.register_patient(name, age)
            elif choice == '2':
                patient_id = int(input("Enter patient ID: "))
                diagnosis = input("Enter diagnosis details: ")
                doctor_name = input("Enter doctor's name: ")
                self.add_diagnosis(patient_id, diagnosis, doctor_name)
            elif choice == '3':
                patient_id = int(input("Enter patient ID: "))
                self.view_patient_reports(patient_id)
            elif choice == '4':
                patient_id = int(input("Enter patient ID: "))
                self.view_latest_report(patient_id)
            elif choice == '5':
                print("Exiting the system.")
                break
            else:
                print("Invalid choice. Please try again.")

if __name__ == "__main__":
    system = HealthMonitoringSystem()
    system.run()

    